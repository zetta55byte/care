"""CARE visualization layer."""
