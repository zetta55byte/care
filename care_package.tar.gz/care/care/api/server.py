"""
CARE FastAPI server.

Endpoints:
    GET  /health
    POST /encode
    POST /risk
    POST /curvature
    POST /escape-route
    POST /recommend
    POST /apply
"""
from __future__ import annotations

import logging
import uuid
from typing import Any

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from care import __version__
from care.config import settings
from care.api.schemas import (
    StateInput,
    HealthResponse,
    EncodeResponse,
    RiskResponse,
    CurvatureResponse,
    EscapeRouteResponse,
    RecommendResponse,
    ApplyResponse,
    Action,
)
from care.models.state_encoder import encode_state
from care.models.risk_potential import get_potential
from care.models.curvature import curvature_info
from care.models.ridge import analyse_ridge, summarise as ridge_summary
from care.models.recommend import recommend_actions
from care.adapters.constitutional_os import propose_delta, apply_delta

logger = logging.getLogger(__name__)

# ── App setup ─────────────────────────────────────────────────────────────────

app = FastAPI(
    title="CARE — Curvature-Aware Risk Engine",
    description=(
        "Keeps infrastructure inside a safe attractor by computing curvature "
        "on system-state risk surfaces and recommending membrane-level interventions. "
        "Theoretical basis: Unified Attractor Grammar (Byte, 2026), "
        "doi:10.5281/zenodo.19394700."
    ),
    version=__version__,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _risk_severity(r: float) -> str:
    if r > settings.high_risk_threshold:
        return "high"
    if r > settings.high_risk_threshold / 3:
        return "medium"
    return "low"


def _pipeline(payload: StateInput):
    """Run the full CARE pipeline and return (x, result, ridge, potential)."""
    potential = get_potential(payload.potential)
    x = encode_state(payload.state)
    result = curvature_info(x, potential, backend=payload.backend)
    ridge = analyse_ridge(result)
    return x, result, ridge, potential


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["meta"])
def health():
    return HealthResponse(version=__version__)


@app.post("/encode", response_model=EncodeResponse, tags=["pipeline"])
def encode(payload: StateInput):
    """Encode raw infra state to a numerical vector x ∈ ℝⁿ."""
    x = encode_state(payload.state)
    return EncodeResponse(vector=x.tolist(), dim=len(x))


@app.post("/risk", response_model=RiskResponse, tags=["pipeline"])
def risk(payload: StateInput):
    """Evaluate the risk potential R(x) at the current state."""
    potential = get_potential(payload.potential)
    x = encode_state(payload.state)
    r = float(potential(x))
    return RiskResponse(risk=r, severity_hint=_risk_severity(r))


@app.post("/curvature", response_model=CurvatureResponse, tags=["pipeline"])
def curvature(payload: StateInput):
    """Compute ∇R, H(x), and eigenstructure (UAG Theorem 3)."""
    _, result, _, _ = _pipeline(payload)
    return CurvatureResponse(
        risk=result.risk,
        gradient=result.gradient.tolist(),
        hessian=result.hessian.tolist(),
        eigenvalues=result.eigenvalues.tolist(),
        backend_used=result.backend_used,
    )


@app.post("/escape-route", response_model=EscapeRouteResponse, tags=["pipeline"])
def escape_route(payload: StateInput):
    """
    Identify the minimum-curvature escape route on the basin boundary.
    Implements UAG Theorem 4: min |λ_min| on ∂B predicts transition locus.
    """
    _, result, ridge, _ = _pipeline(payload)
    return EscapeRouteResponse(**ridge_summary(ridge))


@app.post("/recommend", response_model=RecommendResponse, tags=["pipeline"])
def recommend(payload: StateInput):
    """
    Generate prioritised hardening actions from curvature analysis.
    Actions map directly to Constitutional OS membrane interventions.
    """
    x, result, ridge, _ = _pipeline(payload)
    actions = recommend_actions(result, ridge, raw_state=payload.state)
    return RecommendResponse(
        actions=[Action(**a.to_dict()) for a in actions],
        n_actions=len(actions),
        severity=ridge.severity,
    )


@app.post("/apply", response_model=ApplyResponse, tags=["pipeline"])
def apply(payload: StateInput):
    """
    Push recommended changes into the Constitutional OS as reversible deltas.
    Requires CARE_COS_ENABLED=true and a running Constitutional OS Runtime.
    """
    if not settings.cos_enabled:
        # Dry-run mode: return what would be applied
        _, result, ridge, _ = _pipeline(payload)
        actions = recommend_actions(result, ridge, raw_state=payload.state)
        delta_ids = [str(uuid.uuid4()) for _ in actions]
        return ApplyResponse(
            status="dry_run",
            delta_ids=delta_ids,
            message=(
                f"Constitutional OS not enabled (CARE_COS_ENABLED=false). "
                f"{len(actions)} action(s) would be applied as deltas. "
                "Set CARE_COS_ENABLED=true to apply."
            ),
        )

    try:
        _, result, ridge, _ = _pipeline(payload)
        actions = recommend_actions(result, ridge, raw_state=payload.state)
        deltas = propose_delta([a.to_dict() for a in actions])
        applied = apply_delta(deltas)
        return ApplyResponse(
            status="accepted",
            delta_ids=[d["id"] for d in applied],
            message=f"Applied {len(applied)} delta(s) via Constitutional OS.",
        )
    except Exception as e:
        logger.exception("Apply failed: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


# ── Dev entrypoint ────────────────────────────────────────────────────────────

def main():
    import uvicorn
    uvicorn.run(
        "care.api.server:app",
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
    )


if __name__ == "__main__":
    main()
