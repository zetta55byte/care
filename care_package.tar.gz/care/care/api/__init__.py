"""CARE API layer."""
