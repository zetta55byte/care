# CARE — Curvature-Aware Risk Engine

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/)

CARE is a runtime controller that keeps infrastructure inside a "safe attractor"
by continuously analysing the curvature of a system's risk landscape.
Infrastructure state (IAM policies, Kubernetes configs, network topology,
or model deployment modes) is encoded into a numerical vector, and a
user-defined risk potential R(x) is evaluated. Using
[hcderiv](https://zenodo.org/records/19433812), CARE computes exact gradients
and Hessians in a single pass, revealing the softest directions in the risk
surface — the paths where misconfigurations, privilege drift, or adversarial
pressure can most easily push the system toward a catastrophic state.

CARE then identifies minimum-curvature escape routes (Theorem 4 in the
[Unified Attractor Grammar](https://doi.org/10.5281/zenodo.19394700)) and uses
curvature-aware optimisation (curvopt / CAO) to propose hardening actions that
deepen the safe basin and raise ridge boundaries. These actions are passed
through Constitutional OS, which enforces membrane constraints, generates
reversible deltas, and ensures rule coherence before applying changes to cloud
or cluster infrastructure. The result is a closed-loop controller that
continuously stabilises the system against drift, misconfiguration, and
adversarial pressure.

This architecture turns the Unified Attractor Grammar into a practical security
substrate: curvature becomes a first-class signal for risk, membranes become
enforceable boundaries, and reversible deltas provide auditable governance.
CARE can be deployed as a standalone service or integrated into existing
security pipelines to provide real-time, mathematically grounded risk
mitigation.

---

## Architecture

```mermaid
flowchart TD
    subgraph External
        A1["Cloud / Infra State\n(IAM, K8s, configs)"]
        A2[Security / Governance Operator]
    end

    subgraph CARE[CARE Core]
        B0[Web UI / API Gateway]
        B1[State Encoder]
        B2[Risk Potential Module]
        B3["Curvature Engine\n(hcderiv)"]
        B4[Ridge & Escape Route Detector]
        B5["Hardening Recommendation Engine\n(curvopt / CAO)"]
        B6[Visualization & Reporting]
    end

    subgraph COS[Constitutional OS Layer]
        C1[Constitutional OS Adapter]
        C2[Constitutional OS Runtime]
        C3["Cloud / Infra APIs\n(AWS, GCP, K8s)"]
    end

    A1 --> B1
    A2 --> B0
    B0 --> B1
    B1 --> B2
    B1 --> B3
    B2 --> B3
    B3 --> B4
    B3 --> B5
    B4 --> B5
    B5 --> B6
    B5 --> C1
    C1 --> C2
    C2 --> C3
    C3 --> A1
```

---

## Theoretical Grounding

CARE operationalises two theorems from the Unified Attractor Grammar:

| UAG Result | CARE Component |
|---|---|
| Theorem 3 — Hessian determines local flow geometry | Curvature Engine: eigenvalues = stiffness map |
| Theorem 4 — Min-|λ| predicts escape route | Ridge Detector: softest direction = highest-risk drift path |
| Constitutional OS membranes | Adapter: every change is membrane-checked before applying |
| Reversible deltas | Membrane module: full rollback + audit log |

---

## Quick Start

```bash
pip install -e ".[dev]"
uvicorn care.api.server:app --reload
python examples/iam_demo/run_demo.py
```

See `examples/iam_demo/` for a walkthrough and `examples/iam_demo/notebook.ipynb`
for an interactive visualisation of the curvature basin.

---

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/encode` | Raw state → vector x |
| POST | `/risk` | R(x) scalar |
| POST | `/curvature` | ∇R, H(x), eigenstructure |
| POST | `/escape-route` | Softest direction + min-action path |
| POST | `/recommend` | Hardening actions list |
| POST | `/apply` | Push deltas into Constitutional OS |
| GET | `/health` | Liveness check |

---

## Replacing Stubs with Real Components

| Stub | Real replacement |
|---|---|
| `state_encoder.py` | `adapters/aws_iam.py`, `adapters/k8s.py` |
| `curvature.py` placeholder | `hcderiv.hessian(f, x, backend="jax-xla")` |
| `recommend.py` placeholder | `curvopt` / CAO gradient steps |
| `constitutional_os.py` stub | Live Constitutional OS delta API |

---

## Project Structure

```
care/
├─ README.md
├─ pyproject.toml
├─ requirements.txt
├─ care/
│  ├─ __init__.py
│  ├─ config.py
│  ├─ models/
│  │  ├─ state_encoder.py
│  │  ├─ risk_potential.py
│  │  ├─ curvature.py
│  │  ├─ ridge.py
│  │  └─ recommend.py
│  ├─ api/
│  │  ├─ server.py
│  │  └─ schemas.py
│  ├─ adapters/
│  │  ├─ aws_iam.py
│  │  ├─ k8s.py
│  │  └─ constitutional_os.py
│  ├─ membranes/
│  │  ├─ policies.py
│  │  └─ deltas.py
│  └─ viz/
│     └─ plots.py
└─ examples/
   ├─ iam_demo/
   │  ├─ iam_state.json
   │  ├─ run_demo.py
   │  └─ notebook.ipynb
   └─ configs/
      └─ demo_config.yaml
```

---

## References

- Byte, Z. (2026). *The Unified Attractor Grammar.* DOI: [10.5281/zenodo.19394700](https://doi.org/10.5281/zenodo.19394700)
- Byte, Z. (2026). *hcderiv v0.4.0.* DOI: [10.5281/zenodo.19433812](https://doi.org/10.5281/zenodo.19433812)
- Byte, Z. (2026). *Constitutional OS.* Preprint.
